"""
tests/test_config.py
"""
from pathlib import Path
import pytest
from effector_motif_pred.config import load_config, PipelineConfig


CONFIG_TEXT = """
input_rxlr_fasta: /dev/null
input_genome_fasta: /dev/null
output_dir: /tmp/test_effector
cdhit_c: 0.9
min_cluster_size: 5
max_iterations: 3
threads:
  cdhit: 2
  hmmsearch: 2
"""


def test_load_config_basic(tmp_path):
    cfg_file = tmp_path / "config.yaml"
    cfg_file.write_text(CONFIG_TEXT)
    cfg = load_config(cfg_file)
    assert isinstance(cfg, PipelineConfig)
    assert cfg.min_cluster_size == 5
    assert cfg.max_iterations == 3
    assert cfg.threads.cdhit == 2


def test_load_config_old_keys(tmp_path):
    """Old Snakemake key names should be silently remapped."""
    old_yaml = """
input_RXLR_files: /dev/null
input_genome_fastafile: /dev/null
workdir: /tmp/test_effector
cdhit_c: 0.9
"""
    cfg_file = tmp_path / "config.yaml"
    cfg_file.write_text(old_yaml)
    cfg = load_config(cfg_file)
    assert cfg.input_rxlr_fasta == Path("/dev/null")
    assert cfg.input_genome_fasta == Path("/dev/null")


def test_fasta_ids_empty(tmp_path):
    from effector_motif_pred.iterate import fasta_ids
    assert fasta_ids(tmp_path / "nonexistent.fa") == set()


def test_fasta_ids(tmp_path):
    from effector_motif_pred.iterate import fasta_ids
    fa = tmp_path / "test.fa"
    fa.write_text(">SEQ1\nACDE\n>SEQ2\nFGHI\n")
    assert fasta_ids(fa) == {"SEQ1", "SEQ2"}
