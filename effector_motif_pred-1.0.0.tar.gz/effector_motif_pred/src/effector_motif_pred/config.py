"""
config.py
---------
Load, validate, and expose pipeline configuration.
"""
from __future__ import annotations

import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

import yaml


# ---------------------------------------------------------------------------
# Default config path shipped with the package
# ---------------------------------------------------------------------------
DEFAULT_CONFIG = Path(__file__).parent / "config_template.yaml"


@dataclass
class ThreadConfig:
    cdhit: int = 8
    hmmsearch: int = 4


@dataclass
class PipelineConfig:
    # --- I/O ---
    input_rxlr_fasta: Path = Path("input.fa")
    input_genome_fasta: Path = Path("genome.fa")
    output_dir: Path = Path("effector_results")

    # --- CD-HIT ---
    cdhit_prog: str = "cd-hit"
    cdhit_c: float = 0.9
    cdhit_d: int = 0

    # --- Cluster filtering ---
    min_cluster_size: int = 10

    # --- Tool binaries ---
    clustalw_bin: str = "clustalw"
    hmmbuild_bin: str = "hmmbuild"
    hmmsearch_bin: str = "hmmsearch"

    # --- Runtime ---
    threads: ThreadConfig = field(default_factory=ThreadConfig)
    max_iterations: int = 20

    def validate(self) -> None:
        """Raise informative errors for missing files or tools."""
        errors: List[str] = []

        for attr, label in [
            ("input_rxlr_fasta", "Input RXLR FASTA"),
            ("input_genome_fasta", "Genome FASTA"),
        ]:
            p = getattr(self, attr)
            if not Path(p).exists():
                errors.append(f"{label} not found: {p}")

        for binary in [self.cdhit_prog, self.clustalw_bin,
                       self.hmmbuild_bin, self.hmmsearch_bin]:
            if shutil.which(binary) is None:
                errors.append(
                    f"Required tool not found in PATH: '{binary}'\n"
                    f"  Install via Conda:  conda install -c bioconda cd-hit hmmer clustalw"
                )

        if errors:
            raise EnvironmentError(
                "Pipeline configuration errors:\n" +
                "\n".join(f"  • {e}" for e in errors)
            )


def load_config(path: str | Path) -> PipelineConfig:
    """
    Load a YAML config file and return a validated PipelineConfig.

    YAML keys (all optional — missing keys fall back to defaults)
    ---------------------------------------------------------------
    input_rxlr_fasta:     path/to/rxlr.fa
    input_genome_fasta:   path/to/all_proteins.fa
    output_dir:           effector_results
    cdhit_prog:           cd-hit
    cdhit_c:              0.9
    cdhit_d:              0
    min_cluster_size:     10
    clustalw_bin:         clustalw
    hmmbuild_bin:         hmmbuild
    hmmsearch_bin:        hmmsearch
    max_iterations:       20
    threads:
      cdhit:              8
      hmmsearch:          4
    """
    with open(path) as fh:
        raw = yaml.safe_load(fh) or {}

    # Support the old config.yaml key names from the Snakemake version
    _compat(raw)

    thread_raw = raw.pop("threads", {}) or {}
    threads = ThreadConfig(
        cdhit=int(thread_raw.get("cdhit", 8)),
        hmmsearch=int(thread_raw.get("hmmsearch", 4)),
    )

    cfg = PipelineConfig(
        input_rxlr_fasta=Path(raw.get("input_rxlr_fasta", "input.fa")),
        input_genome_fasta=Path(raw.get("input_genome_fasta", "genome.fa")),
        output_dir=Path(raw.get("output_dir", "effector_results")),
        cdhit_prog=raw.get("cdhit_prog", "cd-hit"),
        cdhit_c=float(raw.get("cdhit_c", 0.9)),
        cdhit_d=int(raw.get("cdhit_d", 0)),
        min_cluster_size=int(raw.get("min_cluster_size", 10)),
        clustalw_bin=raw.get("clustalw_bin", "clustalw"),
        hmmbuild_bin=raw.get("hmmbuild_bin", "hmmbuild"),
        hmmsearch_bin=raw.get("hmmsearch_bin", "hmmsearch"),
        threads=threads,
        max_iterations=int(raw.get("max_iterations", 20)),
    )
    return cfg


def _compat(raw: dict) -> None:
    """Silently map old Snakemake/R config keys → new key names."""
    mapping = {
        "input_RXLR_files":       "input_rxlr_fasta",
        "input_genome_fastafile": "input_genome_fasta",
        "workdir":                "output_dir",
        "final_output_files":     None,   # derived automatically now
    }
    for old, new in mapping.items():
        if old in raw:
            if new:
                raw.setdefault(new, raw.pop(old))
            else:
                raw.pop(old, None)
