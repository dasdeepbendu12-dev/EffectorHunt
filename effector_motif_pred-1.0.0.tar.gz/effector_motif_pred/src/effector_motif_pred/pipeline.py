"""
pipeline.py
-----------
Run one full iteration of the effector motif prediction pipeline:

    CD-HIT → filter → ClustalW → hmmbuild → hmmsearch (parallel) → collect
"""
from __future__ import annotations

import re
import subprocess
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Set

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
from rich.console import Console
from rich.progress import track

from .config import PipelineConfig

console = Console(stderr=True)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_single_iteration(
    input_fasta: Path,
    workdir: Path,
    cfg: PipelineConfig,
) -> Path:
    """
    Execute one pipeline iteration.

    Parameters
    ----------
    input_fasta : Path
        Seed FASTA for this round (RXLR effectors).
    workdir : Path
        Directory for all intermediate files for this round.
    cfg : PipelineConfig
        Validated pipeline configuration.

    Returns
    -------
    Path
        Path to the output FASTA containing the deduplicated HMM hits.
    """
    _make_dirs(workdir)

    # 1. CD-HIT clustering
    clustered_fa, clstr_file = _run_cdhit(input_fasta, workdir, cfg)

    # 2. Parse + filter clusters
    clusters = _parse_clstr(clstr_file)
    kept = {cid: members for cid, members in clusters.items()
            if len(members) >= cfg.min_cluster_size}
    console.log(
        f"[cyan]Clusters after CD-HIT:[/] {len(clusters)}  "
        f"[green]kept (≥{cfg.min_cluster_size} seqs):[/] {len(kept)}"
    )

    if not kept:
        console.log("[yellow]No clusters passed the size filter — "
                    "returning empty result.[/]")
        out_fasta = workdir / "final.fasta"
        out_fasta.write_text("")
        return out_fasta

    # 3. Load input sequences (ID-keyed)
    seed_seqs: Dict[str, SeqRecord] = {
        rec.id.split()[0]: rec
        for rec in SeqIO.parse(input_fasta, "fasta")
    }

    # 4. Write per-cluster FASTAs, align, build HMMs, search — all at once
    tbl_paths = _process_clusters(kept, seed_seqs, workdir, cfg)

    # 5. Collect unique hit IDs from all tbl files
    hit_ids = _collect_hits(tbl_paths)
    console.log(f"[green]Unique HMM hits this round:[/] {len(hit_ids)}")

    # 6. Write final FASTA from genome DB
    out_fasta = workdir / "final.fasta"
    _extract_sequences(hit_ids, cfg.input_genome_fasta, out_fasta)

    return out_fasta


# ---------------------------------------------------------------------------
# Step implementations
# ---------------------------------------------------------------------------

def _make_dirs(workdir: Path) -> None:
    for sub in ("cdhit", "clusters", "aln", "hmm", "hmmsearch", "lists"):
        (workdir / sub).mkdir(parents=True, exist_ok=True)


def _run_cdhit(fasta: Path, workdir: Path, cfg: PipelineConfig):
    """Run CD-HIT and return (clustered_fa, clstr_file)."""
    out_fa = workdir / "cdhit" / "clustered.fasta"
    clstr = Path(str(out_fa) + ".clstr")
    cmd = [
        cfg.cdhit_prog,
        "-i", str(fasta),
        "-o", str(out_fa),
        "-c", str(cfg.cdhit_c),
        "-n", str(_cdhit_word_length(cfg.cdhit_c)),
        "-d", str(cfg.cdhit_d),
        "-T", str(cfg.threads.cdhit),
    ]
    console.log(f"[bold]CD-HIT[/] → {out_fa.name}")
    _run(cmd)
    return out_fa, clstr



def _cdhit_word_length(threshold: float) -> int:
    """
    Return the correct CD-HIT word length (-n) for a given identity threshold.
    CD-HIT requires specific word lengths per threshold band — using the wrong
    value causes CD-HIT to exit with an error.

    CD-HIT word length table (from CD-HIT documentation):
      >= 0.7  → n = 5
      >= 0.6  → n = 4
      >= 0.5  → n = 3
      >= 0.4  → n = 2
    """
    if threshold >= 0.7:
        return 5
    elif threshold >= 0.6:
        return 4
    elif threshold >= 0.5:
        return 3
    else:
        return 2


def _parse_clstr(clstr_file: Path) -> Dict[str, List[str]]:
    """
    Parse a CD-HIT .clstr file.

    Returns dict: {cluster_id: [seq_id, ...]}
    """
    clusters: Dict[str, List[str]] = defaultdict(list)
    current: str | None = None
    pattern = re.compile(r">(.+?)\.\.\.")    # matches >SEQID... (IDs may contain dots)

    for line in clstr_file.read_text().splitlines():
        if line.startswith(">Cluster"):
            current = line.split()[-1]          # "0", "1", …
        elif current is not None and ">" in line:
            m = pattern.search(line)
            if m:
                clusters[current].append(m.group(1))

    return dict(clusters)


def _process_clusters(
    kept: Dict[str, List[str]],
    seed_seqs: Dict[str, SeqRecord],
    workdir: Path,
    cfg: PipelineConfig,
) -> List[Path]:
    """
    For every kept cluster:
      • write FASTA
      • run ClustalW
      • run hmmbuild
      • run hmmsearch  (all hmmsearches run in parallel)

    Returns list of .tbl paths.
    """
    # --- Write cluster FASTAs and prepare alignment jobs ---
    cluster_fastas: Dict[str, Path] = {}
    for cid, members in kept.items():
        fa_path = workdir / "clusters" / f"cluster_{cid}.fa"
        recs = [seed_seqs[sid] for sid in members if sid in seed_seqs]
        SeqIO.write(recs, str(fa_path), "fasta")
        cluster_fastas[cid] = fa_path

    # --- ClustalW → hmmbuild (sequential per cluster, fast enough) ---
    hmm_paths: Dict[str, Path] = {}
    for cid in track(cluster_fastas, description="ClustalW + hmmbuild"):
        fa = cluster_fastas[cid]
        aln = workdir / "aln" / f"cluster_{cid}.aln"
        hmm = workdir / "hmm" / f"cluster_{cid}.hmm"

        n_seqs = sum(1 for _ in SeqIO.parse(str(fa), "fasta"))
        if n_seqs < 2:
            console.log(f"[yellow]Skipping cluster {cid} "
                        f"(only {n_seqs} sequence after filtering)[/]")
            continue

        _run([cfg.clustalw_bin,
              f"-INFILE={fa}", f"-OUTFILE={aln}", "-OUTPUT=CLUSTAL"],
             label=f"clustalw cluster {cid}")

        _run([cfg.hmmbuild_bin, str(hmm), str(aln)],
             label=f"hmmbuild cluster {cid}")

        hmm_paths[cid] = hmm

    # --- hmmsearch in parallel ---
    tbl_paths: List[Path] = []
    console.log(f"[bold]hmmsearch[/] — running {len(hmm_paths)} HMMs "
                f"with {cfg.threads.hmmsearch} threads each "
                f"(parallel workers = 4)")

    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = {
            pool.submit(
                _hmmsearch_one, cid, hmm, workdir, cfg
            ): cid
            for cid, hmm in hmm_paths.items()
        }
        for fut in as_completed(futures):
            cid = futures[fut]
            tbl = fut.result()
            if tbl:
                tbl_paths.append(tbl)

    return tbl_paths


def _hmmsearch_one(cid: str, hmm: Path, workdir: Path,
                   cfg: PipelineConfig) -> Path | None:
    """Run hmmsearch for a single cluster. Called from the thread pool."""
    tbl = workdir / "hmmsearch" / f"cluster_{cid}.tbl"
    out = workdir / "hmmsearch" / f"cluster_{cid}.out"
    cmd = [
        cfg.hmmsearch_bin,
        "--cpu", str(cfg.threads.hmmsearch),
        "--tblout", str(tbl),
        str(hmm),
        str(cfg.input_genome_fasta),
    ]
    with open(out, "w") as fh:
        result = subprocess.run(cmd, stdout=fh, stderr=subprocess.PIPE)

    if result.returncode != 0:
        console.log(f"[red]hmmsearch failed for cluster {cid}:[/] "
                    f"{result.stderr.decode()[:200]}")
        return None

    return tbl


def _collect_hits(tbl_paths: List[Path]) -> Set[str]:
    """Read all hmmsearch tbl files and return unique sequence IDs."""
    hits: Set[str] = set()
    for tbl in tbl_paths:
        for line in tbl.read_text().splitlines():
            if line.startswith("#") or not line.strip():
                continue
            parts = line.split()
            if parts:
                hits.add(parts[0])          # column 0 = target name
    return hits


def _extract_sequences(ids: Set[str], genome_fa: Path,
                       out_fasta: Path) -> None:
    """Extract sequences matching `ids` from the genome FASTA."""
    recs = [
        rec for rec in SeqIO.parse(str(genome_fa), "fasta")
        if rec.id in ids
    ]
    SeqIO.write(recs, str(out_fasta), "fasta")
    console.log(f"[green]Wrote {len(recs)} sequences →[/] {out_fasta}")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run(cmd: List[str], label: str = "") -> None:
    """Run a subprocess, raising CalledProcessError on failure."""
    result = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    if result.returncode != 0:
        raise subprocess.CalledProcessError(
            result.returncode, cmd,
            output=result.stdout,
            stderr=result.stderr,
        )
