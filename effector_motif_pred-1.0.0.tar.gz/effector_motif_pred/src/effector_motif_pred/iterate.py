"""
iterate.py
----------
Run the pipeline repeatedly until convergence (same hit IDs as previous round)
or until max_iterations is reached.
"""
from __future__ import annotations

from pathlib import Path
from typing import Set

from Bio import SeqIO
from rich.console import Console

from .config import PipelineConfig
from .pipeline import run_single_iteration

console = Console(stderr=True)


def fasta_ids(fasta: Path) -> Set[str]:
    """Return the set of sequence IDs in a FASTA file (empty set if missing)."""
    if not fasta.exists():
        return set()
    return {rec.id for rec in SeqIO.parse(str(fasta), "fasta")}


def iterate_pipeline(cfg: PipelineConfig) -> Path:
    """
    Run the motif prediction pipeline iteratively until convergence.

    Each round uses the hit FASTA from the previous round as the new seed.
    Convergence is detected when the set of hit IDs does not change between
    consecutive rounds.

    Parameters
    ----------
    cfg : PipelineConfig
        Fully validated pipeline configuration.

    Returns
    -------
    Path
        Path to the final converged FASTA file.
    """
    cfg.validate()

    base_dir = cfg.output_dir.resolve()
    base_dir.mkdir(parents=True, exist_ok=True)

    prev_fasta: Path = cfg.input_rxlr_fasta.resolve()
    prev_ids: Set[str] = fasta_ids(prev_fasta)

    console.rule("[bold blue]Effector Motif Prediction Pipeline[/]")
    console.log(f"Seed FASTA  : {prev_fasta}")
    console.log(f"Genome FASTA: {cfg.input_genome_fasta}")
    console.log(f"Output dir  : {base_dir}")
    console.log(f"Max iters   : {cfg.max_iterations}")

    for i in range(1, cfg.max_iterations + 1):
        console.rule(f"[bold]Iteration {i}[/]")

        workdir = base_dir / f"iter{i}"
        workdir.mkdir(exist_ok=True)

        out_fasta = run_single_iteration(
            input_fasta=prev_fasta,
            workdir=workdir,
            cfg=cfg,
        )

        new_ids = fasta_ids(out_fasta)

        console.log(
            f"Prev hits: {len(prev_ids)}  "
            f"New hits: {len(new_ids)}  "
            f"Δ = {len(new_ids - prev_ids)} new / "
            f"{len(prev_ids - new_ids)} lost"
        )

        if new_ids == prev_ids:
            console.rule(
                f"[bold green]✔ Converged at iteration {i}[/]",
                style="green",
            )
            console.log(f"Final FASTA: {out_fasta}")
            return out_fasta

        prev_fasta = out_fasta
        prev_ids = new_ids

    console.rule(
        f"[bold yellow]Max iterations ({cfg.max_iterations}) reached "
        "without full convergence[/]",
        style="yellow",
    )
    console.log(f"Final FASTA: {prev_fasta}")
    return prev_fasta
