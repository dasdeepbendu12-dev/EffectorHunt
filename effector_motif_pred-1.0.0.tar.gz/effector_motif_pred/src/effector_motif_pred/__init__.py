"""
effector_motif_pred
===================
Iterative Phytophthora RXLR effector motif prediction pipeline.

Workflow per iteration
----------------------
  1. CD-HIT  — cluster input sequences by identity
  2. Filter  — drop clusters below min_cluster_size
  3. ClustalW — multiple-sequence alignment per cluster
  4. hmmbuild — build Hidden Markov Model per cluster
  5. hmmsearch — search HMMs against the genome database (parallel)
  6. Collect  — pool unique hits → new FASTA seed for next round

Convergence is detected when the set of hit IDs is identical to the
previous round; the pipeline then terminates and returns the final FASTA.
"""

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("effector-motif-pred")
except PackageNotFoundError:
    __version__ = "dev"

from .pipeline import run_single_iteration
from .iterate import iterate_pipeline
from .config import load_config, PipelineConfig

__all__ = [
    "run_single_iteration",
    "iterate_pipeline",
    "load_config",
    "PipelineConfig",
    "__version__",
]
