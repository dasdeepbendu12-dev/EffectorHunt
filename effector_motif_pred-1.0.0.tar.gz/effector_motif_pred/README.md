# effector-motif-pred

**Iterative Phytophthora RXLR effector motif prediction pipeline**

Hunts for highly-diverged effector proteins by iteratively building Hidden
Markov Models from clustered sequences and searching a genome database until
the hit set converges.

```
Seed FASTA ──► CD-HIT ──► ClustalW ──► hmmbuild ──► hmmsearch ──► Hits FASTA
                                                                        │
                            ◄─────────── (new seed if hits changed) ◄──┘
```

---

## Requirements

### Python
- Python ≥ 3.9
- pip

### Bioinformatics tools (must be on PATH)
Install via **Conda** (recommended):

```bash
conda create -n effector_tools -c bioconda -c conda-forge \
    cd-hit hmmer clustalw -y
conda activate effector_tools
```

Or via your Linux package manager if available.

---

## Installation

### Option A — install directly from source (recommended)

```bash
git clone https://github.com/yourlab/effector-motif-pred.git
cd effector-motif-pred
pip install .
```

### Option B — editable / development install

```bash
pip install -e ".[dev]"
```

### Option C — install from a tarball (sharing with colleagues)

```bash
pip install effector_motif_pred-1.0.0.tar.gz
```

To build the tarball:
```bash
pip install build
python -m build --sdist
# tarball appears in dist/
```

---

## Quick start

**1. Create a config file in your working directory:**

```bash
effector-motif-pred init
# → writes config.yaml with all defaults
```

**2. Edit `config.yaml`** to point at your files:

```yaml
input_rxlr_fasta:   path/to/128_Phytopthora_RXLR.fa
input_genome_fasta: path/to/all_128_effectors_fix.fa
output_dir:         effector_results
min_cluster_size:   10
max_iterations:     20
threads:
  cdhit:      8
  hmmsearch:  4
```

**3. Verify your environment:**

```bash
effector-motif-pred check --config config.yaml
```

**4. Run the pipeline:**

```bash
effector-motif-pred run --config config.yaml
```

Results appear in `effector_results/iter1/`, `iter2/`, … with the final
converged FASTA at the path printed at the end.

---

## Python API

You can also drive the pipeline from your own scripts:

```python
from effector_motif_pred import load_config, iterate_pipeline

cfg = load_config("config.yaml")
final_fasta = iterate_pipeline(cfg)
print(f"Done: {final_fasta}")
```

Or run just one iteration:

```python
from pathlib import Path
from effector_motif_pred import load_config, run_single_iteration

cfg = load_config("config.yaml")
out = run_single_iteration(
    input_fasta=Path("my_seed.fa"),
    workdir=Path("iter1"),
    cfg=cfg,
)
```

---

## Output structure

```
effector_results/
├── iter1/
│   ├── cdhit/          CD-HIT output
│   ├── clusters/       per-cluster FASTA files
│   ├── aln/            ClustalW alignments
│   ├── hmm/            HMM profiles
│   ├── hmmsearch/      search results (.tbl + .out)
│   ├── lists/          unique_hits.txt
│   └── final.fasta     ← seed for iter2
├── iter2/
│   └── ...
└── iterN/
    └── final.fasta     ← converged result
```

---

## Migrating from the old config.yaml (Snakemake version)

The old key names are automatically remapped — your original config file
will work without any edits:

| Old key | New key |
|---------|---------|
| `input_RXLR_files` | `input_rxlr_fasta` |
| `input_genome_fastafile` | `input_genome_fasta` |
| `workdir` | `output_dir` |
| `final_output_files` | *(derived automatically)* |

---

## Running tests

```bash
pip install -e ".[dev]"
pytest
```

---

## License

MIT
